from tkinter import *
import tkinter.scrolledtext as tkst
import re

class LexicalAnalyzer:
    def __init__(self, master):
        self.master = master
        self.master.title("Lexical Analyzer")
        self.master.bind("<Escape>", self.quitFunc)
        self.master.bind("<Return>", self.nextLineFunc)
        # variables
        self. currentLine = 0
        # create tokenList
        """
        self.tokenMap = { 
            ("keyword", "if") : re.compile(r'((?<=[\s])|^|\b)if(?=[\(,:,\s,=])'),
            ("keyword", "else") : re.compile(r'((?<=[\s])|^|\b)else(?=[\(,:,\s,=])'),
            ("keyword", "int") : re.compile(r'((?<=[\s])|^|\b)int(?=[\(,:,\s,=])'),
            ("operator", "=") : re.compile(r'='),
            ("operator", "+") : re.compile(r'\+'),
            ("operator", ">") : re.compile(r'>'),
            ("separator", "(") : re.compile(r'\('),
            ("separator", ")") : re.compile(r'\)'),
            ("separator", ":") : re.compile(r':'),
            ("separator", "\"") : re.compile(r'"'),
            ("identifier", "var") : re.compile(r'((?<=[\s])|^|\b)[A-Za-z]+\d{0,}(?=[\(,:,\s,=])'),
            ("literal", "int") : re.compile(r'((?<=[\s])|^|\b)\d+(?=[\(,:,\s,=])'),
            ("literal", "string") : re.compile(r'((?<=["])(?=["])'),
        }
        """
        # add labels
        self.inputLabel = Label(master, text = "Source Code Input:").grid(row = 0, column = 0, sticky =W, padx = 20, pady = 5)
        self.outputLabel = Label(master, text = "Lexical Analyzed Result:").grid(row = 0, column = 1, sticky = W, padx = 20, pady = 5)
        self.lineLabel = Label(master, text = "Current Processing Line:").grid(row = 2, column = 0, sticky = W, padx = 20)
        # add scrolled text widgets
        self.inputText = tkst.ScrolledText(master, wrap = WORD, width = 40, height = 15)
        self.inputText.grid(row=1,column=0,sticky=E,padx=20,pady=5)
        self.outputText = tkst.ScrolledText(master, wrap = WORD, width = 40, height = 15)
        self.outputText.grid(row=1,column=1,sticky=E,padx=20,pady=5)
        self.outputText.configure(state = "disabled")
        # add button widgets
        self.nextLineBtn = Button(master, text = "Next Line", command = self.nextLineFunc).grid(row = 3, column = 0, sticky = E, padx = 20, pady = 5)
        self.quitBtn = Button(master, text = "Quit", command = self.quitFunc).grid(row = 3, column = 1, sticky = E, padx = 20, pady = 5)
        # add current line counter
        self.currentLnCounter = Text(master, wrap = WORD, width = 4, height = 1)
        self.currentLnCounter.grid(row=2,column=0,sticky=E,padx = 20, pady = 5)
        self.currentLnCounter.delete(1.0, "end")
        self.currentLnCounter.insert("end", self.currentLine)
        self.currentLnCounter.configure(state="disabled")

    def nextLineFunc(self, Event = None):
        # process current line
        self.parsedStr = self.inputText.get(str(self.currentLine+1)+".0", str(self.currentLine+2)+".0")
        # insert line into output text
        self.outputText.configure(state = "normal")
        self.outputText.insert(INSERT, self.parsedStr)
        self.outputText.configure(state = "disabled")
        # increment current line & update current line display
        self.currentLine = self.currentLine + 1
        self.currentLnCounter.configure(state = "normal")
        self.currentLnCounter.delete(1.0, "end")
        self.currentLnCounter.insert("end", self.currentLine)
        self.currentLnCounter.configure(state = "disabled")
        return
    
    def quitFunc(self, Event = None):
        self.master.destroy()
        return

    def tokenize(self, stringthing):
        
        #for token in self.tokenMap:
        #   print("Hi")
        return

root = Tk()
analyzer = LexicalAnalyzer(root)
root.mainloop()